import React, { PureComponent } from 'react';
import { WriterWrapper } from '../style';

class Writer extends PureComponent {

	render() {
		return (
			<WriterWrapper>HomeWork</WriterWrapper>
		)
	}
}

export default Writer;
